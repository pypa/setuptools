"svn structure and externals examples" 
